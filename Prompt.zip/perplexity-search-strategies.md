# Perplexity AI 검색 최적화 전략

## 1. 정확도 향상 전략

### English Version
```english
1. Time-Based Precision
[Note: Specify temporal context for more accurate results]

Time Specification Patterns
EXAMPLES:
- "as of [specific date]"
- "within the last [time period]"
- "latest developments since [date]"
- "current status in 2024"
- "future projections for 2025"
END EXAMPLES

2. Source Quality Control
[Note: Guide the search toward reliable sources]

Quality Indicators
EXAMPLES:
- "from verified sources"
- "based on research papers"
- "citing official documentation"
- "including expert opinions"
- "with statistical evidence"
END EXAMPLES
```

### 한글 버전
```korean
1. 시간 기반 정확도
[참고: 더 정확한 결과를 위한 시간적 컨텍스트 지정]

시간 명시 패턴
예시:
- "[특정 날짜] 기준"
- "최근 [기간] 동안"
- "[날짜] 이후 최신 발전사항"
- "2024년 현재 상태"
- "2025년 향후 전망"
예시 끝

2. 소스 품질 관리
[참고: 신뢰할 수 있는 소스로 검색 유도]

품질 지표
예시:
- "검증된 출처에서"
- "연구 논문 기반"
- "공식 문서 인용"
- "전문가 의견 포함"
- "통계적 증거 포함"
예시 끝
```

## 2. 검색 깊이 최적화

### English Version
```english
1. Depth Specification
[Note: Guide the level of analysis needed]

Analysis Level Indicators
EXAMPLES:
- "Provide comprehensive analysis of"
- "Analyze in-depth implications of"
- "Examine systemic effects of"
- "Investigate root causes of"
- "Explore interconnections between"
END EXAMPLES

2. Multi-Perspective Analysis
EXAMPLES:
- "Compare different viewpoints on"
- "Analyze contrasting approaches to"
- "Evaluate various solutions for"
- "Consider multiple scenarios for"
- "Assess different strategies for"
END EXAMPLES
```

### 한글 버전
```korean
1. 깊이 명시
[참고: 필요한 분석 수준 안내]

분석 수준 지표
예시:
- "포괄적 분석 제공"
- "심층적 함의 분석"
- "시스템적 영향 검토"
- "근본 원인 조사"
- "상호 연관성 탐구"
예시 끝

2. 다각적 분석
예시:
- "다양한 관점 비교"
- "대조적 접근법 분석"
- "다양한 해결책 평가"
- "복수 시나리오 고려"
- "다양한 전략 평가"
예시 끝
```

## 3. 결과 구체화 전략

### English Version
```english
1. Output Format Specification
[Note: Specify desired output format]

Format Requests
EXAMPLES:
- "Provide analysis in table format"
- "Include comparative charts"
- "Present step-by-step breakdown"
- "Organize findings by category"
- "List pros and cons for each option"
END EXAMPLES

2. Detail Level Requirements
EXAMPLES:
- "Include specific examples"
- "Provide quantitative data"
- "Add practical case studies"
- "Include implementation details"
- "Specify resource requirements"
END EXAMPLES
```

### 한글 버전
```korean
1. 출력 형식 명시
[참고: 원하는 출력 형식 지정]

형식 요청
예시:
- "표 형식으로 분석 제공"
- "비교 차트 포함"
- "단계별 분석 제시"
- "카테고리별 결과 정리"
- "각 옵션의 장단점 나열"
예시 끝

2. 세부사항 수준 요구
예시:
- "구체적 예시 포함"
- "정량적 데이터 제공"
- "실제 사례 연구 추가"
- "구현 세부사항 포함"
- "리소스 요구사항 명시"
예시 끝
```

## 4. 순차적 검색 최적화

### English Version
```english
1. Progressive Refinement
[Note: Use step-by-step refinement for better results]

Refinement Pattern
EXAMPLES:
Initial Query: "Overview of [topic]"
Follow-up: "Deeper analysis of [specific aspect]"
Final: "Detailed examination of [key finding]"
END EXAMPLES

2. Context Building
EXAMPLES:
- "Based on previous findings..."
- "Following up on [aspect]..."
- "Considering these factors..."
- "In light of this analysis..."
- "Building on these insights..."
END EXAMPLES
```

### 한글 버전
```korean
1. 점진적 개선
[참고: 더 나은 결과를 위한 단계별 개선 사용]

개선 패턴
예시:
초기 질문: "[주제] 개요"
후속 질문: "[특정 측면] 심층 분석"
최종 질문: "[주요 발견] 상세 검토"
예시 끝

2. 컨텍스트 구축
예시:
- "이전 발견사항 기반..."
- "[측면]에 대한 후속 분석..."
- "이러한 요소들을 고려하여..."
- "이 분석을 바탕으로..."
- "이러한 통찰을 발전시켜..."
예시 끝
```

---
These strategies help optimize search results from Perplexity AI for more accurate, detailed, and relevant information.
이러한 전략들은 Perplexity AI에서 더 정확하고 상세하며 관련성 높은 정보를 얻는데 도움을 줍니다.