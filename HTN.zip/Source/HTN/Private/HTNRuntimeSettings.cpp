// Copyright 2020-2025 Maksym Maisak. All Rights Reserved.

#include "HTNRuntimeSettings.h"

UHTNRuntimeSettings::UHTNRuntimeSettings() :
	bEnableNodeInstancePooling(false)
{}
