# Game Developer Software Business Opportunity Analysis

## English Version
```english
Analyze software business opportunities for game developers:

1. Current Skill Assessment
[Note: Please analyze transferable skills in the following categories]

Core Technical Skills
EXAMPLES:
- Real-time system optimization
- Performance tuning
- Multi-threaded programming
END EXAMPLES

Graphics & Visualization Skills
EXAMPLES:
- 3D rendering
- UI/UX development
- Real-time graphics processing
END EXAMPLES

System Architecture Skills
EXAMPLES:
- Scalable system design
- Memory management
- Resource optimization
END EXAMPLES

2. Market Opportunity Analysis
[Note: For each identified skill set, analyze potential business opportunities]

High-Demand Markets
EXAMPLES:
- Data visualization solutions
- Real-time monitoring systems
- Interactive business tools
END EXAMPLES

Assessment Criteria:
- Current market demand
- Competition level
- Entry barriers
- Growth potential
- Required additional skills
- Time to market
- Initial investment needs

3. Business Model Suggestions
[Note: Analyze viable business models based on identified opportunities]

Service Types
EXAMPLES:
- Specialized development tools
- Business visualization platforms
- Real-time analytics solutions
END EXAMPLES

For each suggested business model, please analyze:
- Revenue potential
- Resource requirements
- Technical complexity
- Market readiness
- Competitive advantage
- Scaling potential

4. Implementation Strategy
[Note: Provide strategic approach for market entry]

Consider:
- Minimum Viable Product definition
- Development timeline
- Required resources
- Marketing strategy
- Growth path
- Risk factors

Please provide detailed analysis with actionable insights and practical recommendations.
```

## 한글 버전
```korean
게임 개발자를 위한 소프트웨어 사업 기회를 분석해주세요:

1. 현재 기술 평가
[참고: 다음 카테고리의 전환 가능한 기술을 분석해주세요]

핵심 기술 스킬
예시:
- 실시간 시스템 최적화
- 성능 튜닝
- 멀티스레드 프로그래밍
예시 끝

그래픽스 및 시각화 스킬
예시:
- 3D 렌더링
- UI/UX 개발
- 실시간 그래픽스 처리
예시 끝

시스템 아키텍처 스킬
예시:
- 확장 가능한 시스템 설계
- 메모리 관리
- 리소스 최적화
예시 끝

2. 시장 기회 분석
[참고: 식별된 각 기술 셋에 대한 잠재적 사업 기회 분석]

고수요 시장
예시:
- 데이터 시각화 솔루션
- 실시간 모니터링 시스템
- 인터랙티브 비즈니스 도구
예시 끝

평가 기준:
- 현재 시장 수요
- 경쟁 수준
- 진입 장벽
- 성장 잠재력
- 필요한 추가 기술
- 시장 진입 시간
- 초기 투자 필요성

3. 비즈니스 모델 제안
[참고: 식별된 기회를 바탕으로 실현 가능한 비즈니스 모델 분석]

서비스 유형
예시:
- 특화된 개발 도구
- 비즈니스 시각화 플랫폼
- 실시간 분석 솔루션
예시 끝

각 제안된 비즈니스 모델에 대해 분석:
- 수익 잠재력
- 리소스 요구사항
- 기술적 복잡성
- 시장 준비도
- 경쟁 우위
- 확장 가능성

4. 구현 전략
[참고: 시장 진입을 위한 전략적 접근 제공]

고려사항:
- 최소 실행 가능 제품 정의
- 개발 일정
- 필요 리소스
- 마케팅 전략
- 성장 경로
- 위험 요소

실행 가능한 통찰과 실용적인 추천사항을 포함한 상세 분석을 제공해주세요.
```

---
This prompt structure provides:
- Clear categorization of existing skills
- Systematic market opportunity analysis
- Practical business model suggestions
- Strategic implementation guidance

이 프롬프트 구조는 다음을 제공합니다:
- 기존 기술의 명확한 분류
- 체계적인 시장 기회 분석
- 실용적인 비즈니스 모델 제안
- 전략적 구현 가이드