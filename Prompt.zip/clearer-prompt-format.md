# Enhanced Analysis Request Format

## English Version
```english
Analyze business opportunities for game developers focusing on skill transfer and market demand:

1. Technical Skill Analysis
Please analyze transferable skills in the following categories:
[Note: Examples provided below are for reference. Please include all relevant skills in your analysis]

Core Programming Skills
EXAMPLES:
- Real-time processing expertise
- Performance optimization
- Multi-threading management
END EXAMPLES

Graphics & UI Skills
EXAMPLES:
- Graphics programming
- Real-time rendering
- Interactive design
END EXAMPLES

Please provide comprehensive analysis of all relevant skills in each category.
```

## 한글 버전
```korean
게임 개발자를 위한 기술 전환 및 시장 수요 중심의 사업 기회를 분석해주세요:

1. 기술 스킬 분석
다음 카테고리의 전환 가능한 스킬을 분석해주세요:
[참고: 아래 제시된 예시들은 참고용입니다. 분석에 모든 관련 스킬을 포함해주세요]

핵심 프로그래밍 스킬
예시:
- 실시간 처리 전문성
- 성능 최적화
- 멀티스레딩 관리
예시 끝

그래픽스 및 UI 스킬
예시:
- 그래픽스 프로그래밍
- 실시간 렌더링
- 인터랙티브 디자인
예시 끝

각 카테고리에 대해 모든 관련 스킬의 포괄적 분석을 제공해주세요.
```

---
Key improvements in this format:
- Clearly marks examples with "EXAMPLES:" and "END EXAMPLES"
- Includes explicit note about examples being for reference
- Requests comprehensive analysis beyond provided examples

주요 개선사항:
- "예시:"와 "예시 끝"으로 예시를 명확히 표시
- 예시가 참고용임을 명시적으로 표기
- 제시된 예시를 넘어선 포괄적 분석 요청