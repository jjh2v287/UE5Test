# 검색-학습 통합 프롬프트 전략

## 1. 탐색적 학습 프레임워크

### English Version
```english
1. Knowledge Discovery Framework
[Note: Combine search and learning in a structured approach]

Initial Exploration
EXAMPLES:
- "Analyze latest developments in [topic] as of 2024 with learning pathways"
- "Explore current best practices in [field] with practical examples"
- "Investigate emerging trends in [area] with implementation guides"

Learning Integration
EXAMPLES:
- "Break down complex aspects of [topic] into learnable modules"
- "Provide progressive understanding pathway for [concept]"
- "Map knowledge requirements for mastering [subject]"

Practical Application
EXAMPLES:
- "Show real-world implementations of [concept] with learning steps"
- "Demonstrate practical applications with tutorial guidance"
- "Present case studies with learning insights"
END EXAMPLES
```

### 한글 버전
```korean
1. 지식 발견 프레임워크
[참고: 구조화된 접근 방식으로 검색과 학습 결합]

초기 탐색
예시:
- "2024년 기준 [주제]의 최신 발전사항을 학습 경로와 함께 분석"
- "[분야]의 현재 모범 사례를 실제 예시와 함께 탐색"
- "[영역]의 새로운 트렌드를 구현 가이드와 함께 조사"

학습 통합
예시:
- "[주제]의 복잡한 측면을 학습 가능한 모듈로 분해"
- "[개념]에 대한 점진적 이해 경로 제공"
- "[주제] 습득을 위한 지식 요구사항 매핑"

실제 적용
예시:
- "[개념]의 실제 구현을 학습 단계와 함께 제시"
- "실습 가이드와 함께 실제 적용 시연"
- "학습 인사이트가 포함된 사례 연구 제시"
예시 끝
```

## 2. 심층 이해 개발 전략

### English Version
```english
1. Comprehensive Understanding Development
[Note: Build deep understanding through integrated search-learning]

Knowledge Building Process
EXAMPLES:
Research Phase:
- "Analyze current state of [topic] with learning implications"
- "Investigate best practices with educational breakdown"
- "Research implementation strategies with learning guidance"

Understanding Phase:
- "Explain core concepts with progressive complexity"
- "Break down advanced topics into digestible segments"
- "Map relationships between key concepts"

Application Phase:
- "Provide hands-on examples with learning checkpoints"
- "Design practical exercises with guidance"
- "Create implementation roadmap with learning milestones"
END EXAMPLES

2. Integration Strategies
EXAMPLES:
Knowledge Synthesis:
- "Combine theoretical knowledge with practical applications"
- "Integrate research findings with learning exercises"
- "Connect current practices with skill development"

Skill Development:
- "Build practical skills through researched examples"
- "Develop expertise through guided practice"
- "Master techniques through analyzed case studies"
END EXAMPLES
```

### 한글 버전
```korean
1. 포괄적 이해 개발
[참고: 통합된 검색-학습을 통한 깊은 이해 구축]

지식 구축 프로세스
예시:
연구 단계:
- "[주제]의 현재 상태를 학습 시사점과 함께 분석"
- "교육적 분석이 포함된 모범 사례 조사"
- "학습 가이드가 포함된 구현 전략 연구"

이해 단계:
- "점진적 복잡성을 가진 핵심 개념 설명"
- "고급 주제를 소화 가능한 세그먼트로 분해"
- "주요 개념 간의 관계 매핑"

적용 단계:
- "학습 체크포인트가 있는 실습 예제 제공"
- "가이드가 포함된 실습 연습 설계"
- "학습 이정표가 있는 구현 로드맵 작성"
예시 끝

2. 통합 전략
예시:
지식 종합:
- "이론적 지식과 실제 응용 결합"
- "연구 결과와 학습 연습 통합"
- "현재 실무와 기술 개발 연결"

기술 개발:
- "연구된 예제를 통한 실무 기술 구축"
- "안내된 실습을 통한 전문성 개발"
- "분석된 사례 연구를 통한 기술 숙달"
예시 끝
```

## 3. 실용적 응용 프레임워크

### English Version
```english
1. Applied Learning Integration
[Note: Focus on practical application of searched knowledge]

Implementation Framework
EXAMPLES:
Research-Based Practice:
- "Study successful implementations with learning guides"
- "Analyze real-world applications with tutorials"
- "Investigate case studies with practical exercises"

Skill Application:
- "Apply researched methods with step-by-step guidance"
- "Implement best practices with learning support"
- "Develop solutions based on analyzed examples"

Knowledge Validation:
- "Verify understanding through practical application"
- "Test knowledge with real-world scenarios"
- "Validate learning through implementation"
END EXAMPLES
```

### 한글 버전
```korean
1. 응용 학습 통합
[참고: 검색된 지식의 실제 적용에 중점]

구현 프레임워크
예시:
연구 기반 실습:
- "학습 가이드가 포함된 성공적 구현 사례 연구"
- "튜토리얼이 포함된 실제 응용 분석"
- "실습 연습이 포함된 사례 연구 조사"

기술 적용:
- "단계별 가이드가 있는 연구된 방법 적용"
- "학습 지원이 포함된 모범 사례 구현"
- "분석된 예제를 기반으로 한 솔루션 개발"

지식 검증:
- "실제 적용을 통한 이해도 확인"
- "실제 시나리오를 통한 지식 테스트"
- "구현을 통한 학습 검증"
예시 끝
```

---
This integrated approach combines the benefits of targeted search with structured learning pathways.
이 통합된 접근 방식은 목표 지향적 검색과 구조화된 학습 경로의 이점을 결합합니다.