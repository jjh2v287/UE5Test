# 학습 최적화 프롬프트 전략

## 1. 학습 단계별 최적화 전략

### English Version
```english
1. Progressive Learning Structure
[Note: Structure learning path from basic to advanced]

Knowledge Building Stages
EXAMPLES:
Stage 1: Foundation Building
- "Explain [concept] for beginners"
- "Provide basic principles of [topic]"
- "Outline fundamental concepts of [subject]"

Stage 2: Understanding Deepening
- "Analyze relationships between [concepts]"
- "Explain mechanisms behind [process]"
- "Compare and contrast [related topics]"

Stage 3: Advanced Integration
- "Synthesize understanding of [complex topics]"
- "Evaluate practical applications of [theory]"
- "Analyze real-world implications of [concept]"
END EXAMPLES

2. Learning Style Adaptation
[Note: Adapt content to different learning styles]

Learning Approach Requests
EXAMPLES:
Visual Learning:
- "Describe [concept] using visual metaphors"
- "Explain [process] with diagrams"
- "Illustrate relationships between [elements]"

Practical Learning:
- "Provide hands-on examples of [concept]"
- "Show step-by-step application of [theory]"
- "Include practical exercises for [skill]"

Analytical Learning:
- "Break down [concept] systematically"
- "Analyze underlying principles of [topic]"
- "Examine logical structure of [theory]"
END EXAMPLES
```

### 한글 버전
```korean
1. 단계적 학습 구조
[참고: 기초부터 고급까지 학습 경로 구조화]

지식 구축 단계
예시:
1단계: 기초 구축
- "초보자를 위한 [개념] 설명"
- "[주제]의 기본 원리 제공"
- "[과목]의 기초 개념 개요"

2단계: 이해 심화
- "[개념들] 간의 관계 분석"
- "[프로세스] 배후의 메커니즘 설명"
- "[관련 주제들] 비교 대조"

3단계: 고급 통합
- "[복잡한 주제들]의 이해 종합"
- "[이론]의 실제 적용 평가"
- "[개념]의 실제 영향 분석"
예시 끝

2. 학습 스타일 적응
[참고: 다양한 학습 스타일에 맞춘 콘텐츠 조정]

학습 접근 요청
예시:
시각적 학습:
- "시각적 비유를 사용한 [개념] 설명"
- "다이어그램을 통한 [프로세스] 설명"
- "[요소들] 간의 관계 도식화"

실습 학습:
- "[개념]의 실습 예제 제공"
- "[이론]의 단계별 적용 시연"
- "[기술]을 위한 실습 과제 포함"

분석적 학습:
- "[개념]의 체계적 분석"
- "[주제]의 근본 원리 분석"
- "[이론]의 논리적 구조 검토"
예시 끝
```

## 2. 이해도 검증 및 강화 전략

### English Version
```english
1. Understanding Verification
[Note: Include checks for comprehension]

Verification Methods
EXAMPLES:
Knowledge Testing:
- "Explain [concept] in your own words"
- "Apply [principle] to a new situation"
- "Identify key aspects of [topic]"

Practical Application:
- "Solve this problem using [method]"
- "Design a solution for [scenario]"
- "Implement [concept] in practice"

Critical Thinking:
- "Analyze strengths and weaknesses of [approach]"
- "Evaluate effectiveness of [solution]"
- "Propose improvements to [system]"
END EXAMPLES

2. Knowledge Reinforcement
EXAMPLES:
Connection Building:
- "Link [new concept] to [known concept]"
- "Find patterns between [topics]"
- "Identify relationships within [domain]"

Application Practice:
- "Create examples of [principle]"
- "Design exercises using [concept]"
- "Develop scenarios for [theory]"
END EXAMPLES
```

### 한글 버전
```korean
1. 이해도 검증
[참고: 이해도 확인을 위한 요소 포함]

검증 방법
예시:
지식 테스트:
- "[개념]을 자신의 말로 설명"
- "새로운 상황에 [원리] 적용"
- "[주제]의 핵심 측면 식별"

실제 적용:
- "[방법]을 사용한 문제 해결"
- "[시나리오]에 대한 해결책 설계"
- "[개념]의 실제 구현"

비판적 사고:
- "[접근법]의 장단점 분석"
- "[해결책]의 효과성 평가"
- "[시스템] 개선안 제시"
예시 끝

2. 지식 강화
예시:
연결 구축:
- "[새로운 개념]을 [알려진 개념]과 연결"
- "[주제들] 간의 패턴 발견"
- "[도메인] 내의 관계 식별"

적용 연습:
- "[원리]의 예시 만들기"
- "[개념]을 사용한 연습 문제 설계"
- "[이론]을 위한 시나리오 개발"
예시 끝
```

## 3. 심화 학습 전략

### English Version
```english
1. Advanced Understanding Development
[Note: Foster deeper comprehension]

Depth Building Methods
EXAMPLES:
Conceptual Mastery:
- "Explore edge cases of [concept]"
- "Analyze limitations of [theory]"
- "Investigate exceptions to [rule]"

System Understanding:
- "Map interactions within [system]"
- "Trace cause-effect chains in [process]"
- "Model behavior of [complex system]"

Integration Skills:
- "Combine [multiple concepts]"
- "Synthesize approaches to [problem]"
- "Create unified framework for [domain]"
END EXAMPLES

2. Expert-Level Development
EXAMPLES:
Advanced Application:
- "Optimize [solution] for [context]"
- "Innovate approaches to [challenge]"
- "Design novel solutions for [problem]"

Knowledge Creation:
- "Develop new theories for [phenomenon]"
- "Generate hypotheses about [system]"
- "Create new frameworks for [domain]"
END EXAMPLES
```

### 한글 버전
```korean
1. 고급 이해 개발
[참고: 더 깊은 이해 촉진]

깊이 구축 방법
예시:
개념 숙달:
- "[개념]의 경계 사례 탐구"
- "[이론]의 한계 분석"
- "[규칙]의 예외 조사"

시스템 이해:
- "[시스템] 내 상호작용 매핑"
- "[프로세스]의 인과 관계 추적"
- "[복잡한 시스템]의 행동 모델링"

통합 기술:
- "[다중 개념] 결합"
- "[문제]에 대한 접근 방식 종합"
- "[도메인]을 위한 통합 프레임워크 생성"
예시 끝

2. 전문가 수준 개발
예시:
고급 응용:
- "[컨텍스트]에 맞춘 [해결책] 최적화"
- "[도전과제]에 대한 혁신적 접근"
- "[문제]에 대한 새로운 해결책 설계"

지식 창출:
- "[현상]에 대한 새로운 이론 개발"
- "[시스템]에 대한 가설 생성"
- "[도메인]을 위한 새로운 프레임워크 창출"
예시 끝
```

---
These strategies help optimize learning processes and knowledge acquisition through structured prompts.
이러한 전략들은 구조화된 프롬프트를 통해 학습 과정과 지식 습득을 최적화하는데 도움을 줍니다.