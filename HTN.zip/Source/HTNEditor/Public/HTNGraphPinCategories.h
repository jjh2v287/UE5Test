// Copyright 2020-2025 Maksym Maisak. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"

struct FHTNGraphPinCategories
{
	static const FName MultipleNodesAllowed;
};