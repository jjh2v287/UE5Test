# 프롬프트 엔지니어링 학습 데이터셋

## 1. 기본 데이터 구조 (Basic Data Structure)

```json
{
    "training_examples": [
        {
            "id": "PE_001",
            "type": "basic_prompt",
            "context": {
                "purpose": "market analysis",
                "domain": "business intelligence",
                "complexity_level": "intermediate",
                "required_output_type": "structured analysis"
            },
            "prompt_template": {
                "english": "Analyze [topic] considering:\n1. Market trends\n2. Competition analysis\n3. Growth opportunities",
                "korean": "[주제]를 다음 관점에서 분석해주세요:\n1. 시장 트렌드\n2. 경쟁 분석\n3. 성장 기회"
            },
            "example_substitutions": [
                {
                    "topic": "AI market in 2024",
                    "complete_prompt": "Analyze AI market in 2024 considering:\n1. Market trends\n2. Competition analysis\n3. Growth opportunities"
                }
            ],
            "success_metrics": {
                "clarity": 0.9,
                "effectiveness": 0.85,
                "response_quality": 0.88
            }
        }
    ],
    "prompt_patterns": [
        {
            "pattern_id": "PP_001",
            "pattern_type": "analysis",
            "structure": {
                "components": [
                    "context_setting",
                    "analysis_points",
                    "specific_requirements"
                ],
                "format": "hierarchical",
                "style": "systematic"
            }
        }
    ]
}
```

## 2. 고급 패턴 데이터 (Advanced Pattern Data)

```json
{
    "advanced_patterns": [
        {
            "id": "AP_001",
            "category": "depth_analysis",
            "pattern_structure": {
                "layers": [
                    {
                        "level": 1,
                        "focus": "surface_analysis",
                        "components": ["basic_facts", "initial_observations", "key_points"]
                    },
                    {
                        "level": 2,
                        "focus": "detailed_analysis",
                        "components": ["patterns", "relationships", "implications"]
                    },
                    {
                        "level": 3,
                        "focus": "meta_analysis",
                        "components": ["system_effects", "hidden_patterns", "future_implications"]
                    }
                ]
            },
            "application_guidelines": {
                "when_to_use": ["complex_topics", "deep_analysis_needed", "strategic_planning"],
                "how_to_adapt": ["context_modification", "depth_adjustment", "focus_shifting"]
            }
        }
    ]
}
```

## 3. 컨텍스트 최적화 데이터 (Context Optimization Data)

```json
{
    "context_optimization": [
        {
            "id": "CO_001",
            "context_type": "technical",
            "optimization_rules": {
                "clarity": {
                    "structure": "hierarchical",
                    "language": "precise",
                    "examples": "technical"
                },
                "depth": {
                    "detail_level": "high",
                    "technical_depth": "advanced",
                    "background_info": "comprehensive"
                }
            },
            "adaptation_rules": {
                "audience_level": {
                    "beginner": {
                        "simplify_terms": true,
                        "add_explanations": true,
                        "increase_examples": true
                    },
                    "expert": {
                        "use_technical_terms": true,
                        "assume_background": true,
                        "focus_on_advanced": true
                    }
                }
            }
        }
    ]
}
```

## 4. 품질 보증 데이터 (Quality Assurance Data)

```json
{
    "quality_metrics": [
        {
            "id": "QM_001",
            "metric_type": "prompt_effectiveness",
            "evaluation_criteria": {
                "clarity": {
                    "weight": 0.3,
                    "measures": ["structure", "language", "specificity"]
                },
                "completeness": {
                    "weight": 0.3,
                    "measures": ["coverage", "depth", "context"]
                },
                "effectiveness": {
                    "weight": 0.4,
                    "measures": ["response_quality", "goal_achievement", "user_satisfaction"]
                }
            },
            "threshold_values": {
                "minimum_acceptable": 0.7,
                "target": 0.8,
                "excellent": 0.9
            }
        }
    ]
}
```

## 5. 사용 예시 및 결과 (Examples and Results)

```json
{
    "implementation_examples": [
        {
            "id": "IE_001",
            "original_request": "시장 분석이 필요합니다",
            "enhanced_prompt": {
                "english": "Provide comprehensive market analysis including:\n1. Current market conditions\n2. Key players and competition\n3. Growth trends and opportunities\n4. Risk factors and challenges\n5. Future market projections",
                "korean": "다음을 포함한 포괄적인 시장 분석을 제공해주세요:\n1. 현재 시장 상황\n2. 주요 플레이어와 경쟁 구도\n3. 성장 트렌드와 기회\n4. 리스크 요인과 도전과제\n5. 미래 시장 전망"
            },
            "results": {
                "response_quality": 0.92,
                "user_satisfaction": 0.88,
                "goal_achievement": 0.90
            }
        }
    ]
}
```

---
This dataset structure provides comprehensive training data for prompt engineering capabilities.
이 데이터셋 구조는 프롬프트 엔지니어링 능력을 위한 포괄적인 학습 데이터를 제공합니다.