// Copyright 2020-2025 Maksym Maisak. All Rights Reserved.

#include "HTNGraphPinCategories.h"

const FName FHTNGraphPinCategories::MultipleNodesAllowed(TEXT("MultipleNodesAllowed"));