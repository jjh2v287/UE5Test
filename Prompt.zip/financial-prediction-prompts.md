# 금융 분석 및 예측 프롬프트 전략

## 1. 시장 분석 프레임워크 (Market Analysis Framework)

### English Version
```english
1. Market Trend Analysis
[Note: Analyze market patterns and trends with specific indicators]

Core Analysis Parameters
EXAMPLES:
Technical Analysis:
- "Analyze [market/asset] trends using key technical indicators"
- "Evaluate price movement patterns in [timeframe]"
- "Identify support and resistance levels with reasoning"

Fundamental Analysis:
- "Examine underlying factors affecting [market/asset]"
- "Analyze economic indicators impacting [sector]"
- "Evaluate market sentiment indicators"

Integration Points:
- "Compare technical and fundamental factors"
- "Analyze correlation between different indicators"
- "Identify leading and lagging signals"
END EXAMPLES

2. Pattern Recognition
EXAMPLES:
Historical Patterns:
- "Identify recurring patterns in [market/asset]"
- "Analyze seasonal trends and cycles"
- "Evaluate pattern reliability metrics"

Current Context:
- "Compare current patterns with historical precedents"
- "Analyze pattern deviation factors"
- "Evaluate pattern strength indicators"
END EXAMPLES
```

### 한글 버전
```korean
1. 시장 트렌드 분석
[참고: 특정 지표를 사용한 시장 패턴 및 트렌드 분석]

핵심 분석 매개변수
예시:
기술적 분석:
- "주요 기술 지표를 사용한 [시장/자산] 트렌드 분석"
- "[기간] 동안의 가격 움직임 패턴 평가"
- "지지선과 저항선 식별 및 근거 제시"

기본적 분석:
- "[시장/자산]에 영향을 미치는 기본 요인 조사"
- "[섹터]에 영향을 미치는 경제 지표 분석"
- "시장 심리 지표 평가"

통합 포인트:
- "기술적 및 기본적 요인 비교"
- "다양한 지표 간의 상관관계 분석"
- "선행 및 후행 신호 식별"
예시 끝

2. 패턴 인식
예시:
역사적 패턴:
- "[시장/자산]의 반복적 패턴 식별"
- "계절적 트렌드와 주기 분석"
- "패턴 신뢰성 지표 평가"

현재 컨텍스트:
- "현재 패턴과 과거 사례 비교"
- "패턴 이탈 요인 분석"
- "패턴 강도 지표 평가"
예시 끝
```

## 2. 예측 모델링 전략 (Prediction Modeling Strategy)

### English Version
```english
1. Multi-Factor Analysis
[Note: Combine multiple analysis approaches for robust predictions]

Analysis Components
EXAMPLES:
Quantitative Factors:
- "Analyze key financial metrics for [asset/market]"
- "Evaluate statistical indicators and trends"
- "Calculate risk metrics and volatility measures"

Qualitative Factors:
- "Assess market sentiment indicators"
- "Analyze news impact and sentiment data"
- "Evaluate regulatory environment changes"

Integration Analysis:
- "Combine quantitative and qualitative insights"
- "Weight different factors by importance"
- "Create comprehensive prediction model"
END EXAMPLES

2. Risk Assessment
EXAMPLES:
Risk Identification:
- "Map potential risk factors for [scenario]"
- "Analyze historical risk patterns"
- "Identify emerging risk factors"

Impact Analysis:
- "Evaluate potential impact magnitude"
- "Assess probability of different scenarios"
- "Calculate risk-adjusted returns"
END EXAMPLES
```

### 한글 버전
```korean
1. 다중 요인 분석
[참고: 견고한 예측을 위한 다중 분석 접근법 결합]

분석 구성요소
예시:
정량적 요인:
- "[자산/시장]의 주요 재무 지표 분석"
- "통계적 지표 및 트렌드 평가"
- "리스크 지표 및 변동성 측정 계산"

정성적 요인:
- "시장 심리 지표 평가"
- "뉴스 영향 및 감성 데이터 분석"
- "규제 환경 변화 평가"

통합 분석:
- "정량적 및 정성적 통찰 결합"
- "중요도별 요인 가중치 부여"
- "종합적 예측 모델 작성"
예시 끝

2. 리스크 평가
예시:
리스크 식별:
- "[시나리오]에 대한 잠재적 리스크 요인 매핑"
- "역사적 리스크 패턴 분석"
- "새로운 리스크 요인 식별"

영향 분석:
- "잠재적 영향 규모 평가"
- "다양한 시나리오의 발생 가능성 평가"
- "리스크 조정 수익률 계산"
예시 끝
```

## 3. 실행 전략 프레임워크 (Execution Strategy Framework)

### English Version
```english
1. Strategy Development
[Note: Create actionable strategies based on analysis]

Strategic Components
EXAMPLES:
Entry/Exit Planning:
- "Define entry points based on [criteria]"
- "Establish exit strategies with targets"
- "Set risk management parameters"

Position Management:
- "Determine position sizing methodology"
- "Define portfolio allocation strategy"
- "Establish rebalancing criteria"

Performance Monitoring:
- "Set performance metrics and benchmarks"
- "Define monitoring frequency and triggers"
- "Establish adjustment criteria"
END EXAMPLES

2. Implementation Guide
EXAMPLES:
Execution Steps:
- "Create step-by-step implementation plan"
- "Define execution timing and conditions"
- "Establish contingency procedures"

Monitoring Framework:
- "Set up tracking mechanisms"
- "Define review periods and criteria"
- "Establish adjustment triggers"
END EXAMPLES
```

### 한글 버전
```korean
1. 전략 개발
[참고: 분석을 기반으로 실행 가능한 전략 수립]

전략적 구성요소
예시:
진입/퇴출 계획:
- "[기준]에 기반한 진입 포인트 정의"
- "목표가 있는 퇴출 전략 수립"
- "리스크 관리 매개변수 설정"

포지션 관리:
- "포지션 크기 결정 방법론"
- "포트폴리오 할당 전략 정의"
- "리밸런싱 기준 수립"

성과 모니터링:
- "성과 지표 및 벤치마크 설정"
- "모니터링 주기 및 트리거 정의"
- "조정 기준 수립"
예시 끝

2. 구현 가이드
예시:
실행 단계:
- "단계별 구현 계획 작성"
- "실행 타이밍 및 조건 정의"
- "비상 절차 수립"

모니터링 프레임워크:
- "추적 메커니즘 설정"
- "검토 주기 및 기준 정의"
- "조정 트리거 설정"
예시 끝
```

---
This framework provides comprehensive strategies for financial analysis and prediction.
이 프레임워크는 금융 분석과 예측을 위한 포괄적인 전략을 제공합니다.