// Copyright 2020-2025 Maksym Maisak. All Rights Reserved.

#include "HTNDelegates.h"

FHTNDelegates::FOnPlanExecutionStarted FHTNDelegates::OnPlanExecutionStarted;
