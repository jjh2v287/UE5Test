# 2025 Industry and Business Trends Analysis Prompts

## 1. Trend Pattern Analysis (트렌드 패턴 분석)

### English Version
```english
Analyze emerging trends and patterns for 2025:

1. Technology Evolution Patterns
[Note: Analyze current trends and their projected evolution]

Key Technology Trends
EXAMPLES:
- AI/ML advancement patterns
- Quantum computing progress
- Green tech development
END EXAMPLES

Industry Impact Assessment
EXAMPLES:
- Digital transformation speed
- Automation adoption rates
- Innovation cycles
END EXAMPLES

2. Market Dynamics
[Note: Analyze shifts in market behavior and consumer preferences]

Consumer Behavior Changes
EXAMPLES:
- Digital service adoption
- Sustainability preferences
- Personalization demands
END EXAMPLES

Investment Flow Analysis
EXAMPLES:
- Venture capital trends
- Corporate investment focus
- R&D spending patterns
END EXAMPLES

Please provide data-driven analysis and specific growth indicators.
```

### 한글 버전
```korean
2025년을 위한 새로운 트렌드와 패턴을 분석해주세요:

1. 기술 진화 패턴
[참고: 현재 트렌드와 예상 진화 방향을 분석해주세요]

주요 기술 트렌드
예시:
- AI/ML 발전 패턴
- 양자 컴퓨팅 진척
- 그린 테크 발전
예시 끝

산업 영향 평가
예시:
- 디지털 전환 속도
- 자동화 도입률
- 혁신 주기
예시 끝

2. 시장 역학
[참고: 시장 행동과 소비자 선호도 변화를 분석해주세요]

소비자 행동 변화
예시:
- 디지털 서비스 채택
- 지속가능성 선호도
- 개인화 요구
예시 끝

투자 흐름 분석
예시:
- 벤처 캐피털 트렌드
- 기업 투자 초점
- R&D 지출 패턴
예시 끝

데이터 기반 분석과 구체적인 성장 지표를 제공해주세요.
```

## 2. Industry Growth Analysis (산업 성장 분석)

### English Version
```english
Analyze potential high-growth industries for 2025:

1. Growth Sector Identification
[Note: Analyze sectors showing strong growth potential]

Emerging Industries
EXAMPLES:
- AI-driven services
- Sustainable energy solutions
- Digital health platforms
END EXAMPLES

Assessment Criteria
- Current growth rate
- Investment momentum
- Innovation potential
- Market size projection
- Regulatory environment
- Competition landscape

2. Company Analysis
[Note: Identify companies positioned for strong growth]

Analysis Parameters
- Market position
- Innovation capability
- Financial strength
- Competitive advantage
- Growth strategy
- Management quality

3. Risk Assessment
- Market volatility factors
- Technological risks
- Regulatory challenges
- Competition threats
- Economic variables
- Global factors

Please provide comprehensive analysis with supporting data.
```

### 한글 버전
```korean
2025년의 높은 성장 잠재력을 가진 산업을 분석해주세요:

1. 성장 섹터 식별
[참고: 강한 성장 잠재력을 보이는 섹터를 분석해주세요]

신흥 산업
예시:
- AI 기반 서비스
- 지속가능 에너지 솔루션
- 디지털 헬스 플랫폼
예시 끝

평가 기준
- 현재 성장률
- 투자 모멘텀
- 혁신 잠재력
- 시장 규모 전망
- 규제 환경
- 경쟁 구도

2. 기업 분석
[참고: 강한 성장이 예상되는 기업을 식별해주세요]

분석 매개변수
- 시장 위치
- 혁신 능력
- 재무 건전성
- 경쟁 우위
- 성장 전략
- 경영진 품질

3. 리스크 평가
- 시장 변동성 요인
- 기술적 리스크
- 규제 과제
- 경쟁 위협
- 경제적 변수
- 글로벌 요인

지원 데이터와 함께 포괄적인 분석을 제공해주세요.
```

## 3. Future Impact Analysis (미래 영향 분석)

### English Version
```english
Analyze potential future impacts and implications:

1. Societal Impact
[Note: Analyze broader implications of identified trends]

Areas of Impact
EXAMPLES:
- Work patterns
- Consumer behavior
- Social structures
END EXAMPLES

2. Economic Implications
EXAMPLES:
- Job market changes
- Wealth distribution
- Economic structures
END EXAMPLES

3. Business Environment
EXAMPLES:
- Business model evolution
- Competitive dynamics
- Innovation requirements
END EXAMPLES

Please provide analysis of both opportunities and challenges.
```

### 한글 버전
```korean
잠재적 미래 영향과 시사점을 분석해주세요:

1. 사회적 영향
[참고: 식별된 트렌드의 광범위한 영향을 분석해주세요]

영향 영역
예시:
- 업무 패턴
- 소비자 행동
- 사회 구조
예시 끝

2. 경제적 시사점
예시:
- 일자리 시장 변화
- 부의 분배
- 경제 구조
예시 끝

3. 비즈니스 환경
예시:
- 비즈니스 모델 진화
- 경쟁 역학
- 혁신 요구사항
예시 끝

기회와 도전과제 모두에 대한 분석을 제공해주세요.
```

---
This analysis framework provides:
- Comprehensive trend identification
- Detailed industry analysis
- Future impact assessment

이 분석 프레임워크는 다음을 제공합니다:
- 포괄적 트렌드 식별
- 상세 산업 분석
- 미래 영향 평가