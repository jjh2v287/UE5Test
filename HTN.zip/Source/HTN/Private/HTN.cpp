// Copyright 2020-2025 Maksym Maisak. All Rights Reserved.

#include "HTN.h"

UBlackboardData* UHTN::GetBlackboardAsset() const { return BlackboardAsset; }
